package com.example.calcul;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    //Variables
    public int Language = 0;
    public String[] EN = {"Best score","Back","Empty"};//1
    public String[] FR = {"Meilleur score","Retour","Vide"};//0
    public int best = 0;
    //Fonction pour initialiser l'activité
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();
        //Fonction pour récupérer les données
        if(intent != null && intent.hasExtra("Language") && intent.getIntExtra("Language",0)!=Language){
            setLang();
        }
        if (intent != null && intent.hasExtra("nbScores")) {
            TextView scores = findViewById(R.id.history_list);
            scores.setText("");
            for (int i = 0; i < intent.getIntExtra("nbScores",0); i++) {
                scores.setText(scores.getText() + "\n" + intent.getIntExtra("scores" + i,0));
                if (intent.getIntExtra("scores" + i,0) > best) {
                    best = intent.getIntExtra("scores" + i,0);
                }
            }
            TextView scoreText = findViewById(R.id.history_score);
            switch (Language){
                case 0://FR
                    scoreText.setText(FR[0]+":"+best);
                    break;
                case 1://EN
                    scoreText.setText(EN[0]+":"+best);
                    break;
            }
        }
        findViewById(R.id.history_previous).setOnClickListener(view -> close());
        findViewById(R.id.history_language).setOnClickListener(view -> setLang());
    }
    //Fonction pour changer la langue
    protected void setLang(){
        //Changement de la langue
        switch (Language){
            case 0:
                Language = 1; ((Button) findViewById(R.id.history_language)).setText("EN");
                break;
            case 1:
                Language = 0; ((Button) findViewById(R.id.history_language)).setText("FR");
                break;
        }
        //Importation des éléments
        Button button = findViewById(R.id.history_previous);
        TextView scoreText = findViewById(R.id.history_score);
        //Changement du texte des éléments
        switch (Language){
            case 0://FR
                scoreText.setText(FR[0]+":"+best);
                button.setText(FR[1]);
                break;
            case 1://EN
                scoreText.setText(EN[0]+":"+best);
                button.setText(EN[1]);
                break;
        }
    }
    //Fonction pour fermer l'activité
    protected void close() {
        finish();
    }
}