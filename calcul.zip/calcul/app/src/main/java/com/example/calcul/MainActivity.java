package com.example.calcul;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
public class MainActivity extends AppCompatActivity {
    //Variables
    public int Language = 0;
    public String[] EN = {"Score","History","OK"}; //1
    public String[] FR = {"Score","Historique","OK"}; //0
    public int nb1, nb2,type,score=0,error=0;
    public List scores = new ArrayList();
    //Fonction pour initialisation
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        //Vérification de la réception de donnée
        if(intent != null && intent.hasExtra("Language") && intent.getIntExtra("Language",0)!=Language){
            setLang();
        }
        if(intent != null && intent.hasExtra("nbScores")){
            for (int i=0;i<intent.getIntExtra("nbScores",0);i++){
                scores.add(intent.getIntExtra("scores"+i,0));
            }
        }
        generateCalcul();
        findViewById(R.id.calcul_button).setOnClickListener(view -> verifyCalcul());
        findViewById(R.id.calcul_history).setOnClickListener(view -> openHistory());
        findViewById(R.id.calcul_language).setOnClickListener(view -> setLang());
    }
    //Fonction pour changer la langue
    protected void setLang(){
        //Changement de la langue
        switch (Language){
            case 0:
                Language = 1; ((Button) findViewById(R.id.calcul_language)).setText("EN");
                break;
            case 1:
                Language = 0; ((Button) findViewById(R.id.calcul_language)).setText("FR");
                break;
        }
        //Importation des éléments
        TextView scoreText = findViewById(R.id.calcul_score);
        Button button = findViewById(R.id.calcul_history);
        Button button2 = findViewById(R.id.calcul_button);
        //Changement du texte des éléments
        switch (Language){
            case 0://FR
                scoreText.setText(FR[0]+":"+score);
                button.setText(FR[1]);
                button2.setText(FR[2]);
                break;
            case 1://EN
                scoreText.setText(EN[0]+":"+score);
                button.setText(EN[1]);
                button2.setText(EN[2]);
                break;
        }
    }
    //Fonction pour ouvrir l'historique (Nouvelle activitée)
    protected void openHistory(){
        try {
            //Génération de l'activité et envoie des données
            Intent myIntent = new Intent(this, MainActivity2.class);
            myIntent.putExtra("Language",Language);
            if(scores.size() > 0){
                myIntent.putExtra("nbScores",scores.size());
                for (int i=0;i<scores.size();i++){
                    myIntent.putExtra("scores"+i,(Integer) scores.get(i));
                }
            }
            startActivity(myIntent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Fonction qui renvoie le type de calcul choisi (INT->CHAR)
    protected String getTypeCalcul(int type){
        //On agit selon la valeur INT envoyée
        switch (type){
            case 0:
                return "+";
            case 1:
                return "-";
            case 2:
                return "x";
            case 3:
                return "/";
            default:
                return "?";
        }
    }
    //Fonction qui permet de compter le nombre d'erreur
    protected void addError(){
        //On affiche une nouvelle croix s'il y a une erreur ou on reset la partie
        switch (error){
            case 0:
                findViewById(R.id.calcul_error1).setVisibility(View.VISIBLE);
                break;
            case 1:
                findViewById(R.id.calcul_error2).setVisibility(View.VISIBLE);
                break;
            case 2:
                findViewById(R.id.calcul_error3).setVisibility(View.VISIBLE);
                break;
            case 3:
                //Reset du jeu et envoie le score au prochain jeu, afin de l'enregistrer (MÉTHODE DE PASSAGE DE DONNÉES ENTRE ACTIVITÉES)
                Intent intent = getIntent();
                scores.add(score);
                intent.putExtra("nbScores",scores.size());
                intent.putExtra("Language",Language);
                for (int i=0;i<scores.size();i++){
                    intent.putExtra("scores"+i,(Integer) scores.get(i));
                }
                finish();
                startActivity(intent);
        }
        //on rajoute une erreur et on génére un nouveau calcul
        error++;
        generateCalcul();
    }
    //Fonction qui permet de vérifier la réponse de l'utilisateur par rapport au calcul
    protected  void verifyCalcul(){
        EditText input = findViewById(R.id.calcul_textbox);
        //Vérification si la réponse n'est pas vide (NULL)
        if(input.getText().length() > 0){
            int response = Integer.parseInt(input.getText().toString().trim());
            input.setText("");
            //On agit selon le type de calcul généré
            switch (type){
                case 0:
                    if(nb1+nb2==response){
                        score++;
                        generateCalcul();
                    }else{
                        addError();
                    }
                    break;
                case 1:
                    if(nb1-nb2==response){
                        score++;
                        generateCalcul();
                    }else{
                        addError();
                    }
                    break;
                case 2:
                    if(nb1*nb2==response){
                        score++;
                        generateCalcul();
                    }else{
                        addError();
                    }
                    break;
                case 3:
                    if(nb1/nb2==response){
                        score++;
                        generateCalcul();
                    }else{
                        addError();
                    }
                    break;
            }
            //On actualise le score
            TextView scoreText = findViewById(R.id.calcul_score);
            switch (Language){
                case 0://FR
                    scoreText.setText(FR[0]+":"+score);
                    break;
                case 1://EN
                    scoreText.setText(EN[0]+":"+score);
                    break;
            }
        }
    }
    //Fonction pour générer un calcul
    protected void generateCalcul(){
        //Générer un nombre
        Random random = new Random();
        nb1 = random.nextInt(100)+1;
        nb2 = random.nextInt(100)+1;
        type = random.nextInt(4);
        //Vérification de la grandeur des nombres
        if(nb1 < nb2){
            int temp = nb1; nb1 = nb2; nb2 = temp;
        }
        //Affichage du calcul
        TextView text1 = findViewById(R.id.calcul_text);
        text1.setText(nb1 + getTypeCalcul(type) + nb2);
    }

}